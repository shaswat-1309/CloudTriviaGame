import json
import boto3
import os

api_gateway_management_api = boto3.client('apigatewaymanagementapi', endpoint_url=os.environ['ENDPOINT_URL'])
client = boto3.client('apigatewaymanagementapi', endpoint_url=os.environ['ENDPOINT_URL'])


def lambda_handler(event, context):
    print(event)
    event_body = json.loads(event['body'])
    question_details = event_body['questionDetails']

    print("question_details response:", question_details)

    game_id = question_details['gameId']
    team = question_details['teamName']
    # user_id = question_details['userId']  # TODO check if the user who requested hint has to be noted down
    question_number = question_details['questionNumber']

    hint = "Hint limit exceeded for the team"

    hint_used = get_hint_used_list(game_id, team)
    print("hint_used already", hint_used)

    if len(hint_used) < 2 or question_number in hint_used:

        hint = get_hint_of_question(game_id, question_number)

        if hint != '':
            update_hint_used(game_id, team, question_number)

    hint_response = {
        'hint': hint
    }
    hint_response_message = json.dumps(hint_response)

    broadcast_to_team(game_id, team, hint_response_message)

    return {
        'statusCode': 200,
        'body': hint_response_message
    }


def get_hint_used_list(game_id, team):
    dynamodb_client = boto3.client('dynamodb')

    # fetch the hint used list for the team from the scoreboard item
    response = dynamodb_client.get_item(
        TableName='Scoreboard',
        Key={
            'game_id': {'S': game_id},
            'team': {'S': team}
        },
        ProjectionExpression='hint_used'
    )

    # extract and return the hint used list value
    hint_used_list = response['Item'].get('hint_used', {'NS': []})
    return set(map(int, hint_used_list.get('NS', [])))


def get_hint_of_question(game_id, question_no):
    hint = ""
    dynamodb_client = boto3.client('dynamodb')

    # fetch hint for the question
    response = dynamodb_client.get_item(
        TableName='GameQuestions',
        Key={
            'game_id': {'S': game_id},
            'question_number': {'N': str(question_no)}
        },
        ProjectionExpression='hint'
    )

    # extract hint from the get item response
    if response['Item']['hint']:
        hint = response['Item']['hint']['S']

    return hint


def update_hint_used(game_id, team, question_number):
    dynamodb_client = boto3.client('dynamodb')

    # update the scoreboard item by appending the question number to the hint used list
    dynamodb_client.update_item(
        TableName='Scoreboard',
        Key={
            'game_id': {'S': game_id},
            'team': {'S': team}
        },
        UpdateExpression='ADD hint_used :question_number',
        ExpressionAttributeValues={
            ':question_number': {'NS': [str(question_number)]}
        }
    )


def broadcast_to_team(game_id, team, hint_message):
    team_participants_connections = get_connections_for_game_and_team(game_id, team)
    print("team_participants_connections", team_participants_connections)

    for connection in team_participants_connections:
        connection_id = connection['connection_id']
        print(connection_id)
        try:
            api_gateway_management_api.post_to_connection(ConnectionId=connection_id, Data=hint_message)
            print("message sent")
        except Exception as e:
            print('Error sending message to connection:', e)


# get connections related to a team
def get_connections_for_game_and_team(game_id, team):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('GameParticipants')

    response = table.query(
        IndexName='GameIdTeamIndex',  # Name of the Global Secondary Index (GSI) containing game_id and team attributes
        KeyConditionExpression='game_id = :game_id_val and team = :team_val',
        ExpressionAttributeValues={
            ':game_id_val': game_id,
            ':team_val': team
        }
    )

    print("GameIdTeamIndex", response)
    connections = response['Items']

    return connections

