import json
import boto3


def lambda_handler(event, context):
    print(event)
    # Parse the WebSocket connection request event
    connection_id = event['requestContext']['connectionId']

    query_params = event.get('queryStringParameters')

    if query_params is None:
        return {
            'statusCode': 400,
            'body': 'Missing game,team and user details in the WebSocket connection request'
        }

    game_id = query_params['gameId']
    team = query_params['teamName']
    user_id = query_params['userId']

    add_participant_response = add_game_participants(connection_id, game_id, team, user_id)

    if add_participant_response:

        add_team_to_scoreboard(game_id, team)

        return {
            'statusCode': 200,
            'body': 'Successfully stored connection details'
        }

    else:

        return {
            'statusCode': 500,
            'body': 'Error storing connection details'
        }


def add_game_participants(connection_id, game_id, team, user_id):
    # Store the connection details in the GameParticipants table

    try:
        item = {
            'connection_id': connection_id,
            'game_id': game_id,
            'team': team,
            'user_id': user_id
        }

        dynamodb = boto3.resource('dynamodb')
        table_name = 'GameParticipants'
        table = dynamodb.Table(table_name)

        response = table.put_item(Item=item)
        print("Item successfully added:", response)
        return True

    except Exception as e:
        print("Error storing connection details:", e)
        return False


def add_team_to_scoreboard(game_id, team_name):
    dynamodb = boto3.client('dynamodb')

    item = {
        'game_id': {'S': game_id},
        'team': {'S': team_name},
        'score': {'N': str(0)},
        'responses': {'M': {}}
    }

    condition_expression = 'attribute_not_exists(game_id) AND attribute_not_exists(team)'

    try:
        # Add the item to the table if the condition is met
        response = dynamodb.put_item(
            TableName='Scoreboard',
            Item=item,
            ConditionExpression=condition_expression
        )

        print(response)
        print(f"Scoreboard entry game - {game_id} and team - {team_name} added successfully")

    except Exception as e:
        print(e)
        print(f"Scoreboard entry game - {game_id} and team - {team_name} was not added")

