import boto3
import json

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('GameParticipants')  # Replace with your table name


def lambda_handler(event, context):
    print(event)
    try:
        # Extract the connectionId and disconnect event data from the event
        connection_id = event['requestContext']['connectionId']
        disconnect_reason = event['requestContext']['disconnectReason']

        # Parse the disconnect event data to get the gameId
        disconnect_event_data = json.loads(disconnect_reason)
        game_id = disconnect_event_data.get('gameId', None)

        print(game_id)

        # If a gameId is found, use it to delete the entry from the table
        if game_id:
            table.delete_item(Key={
                'game_id': game_id,
                'connection_id': connection_id
            })

        return {
            'statusCode': 200,
            'body': 'Connection details removed successfully.',
        }

    except Exception as e:
        print('Error removing connection details:', e)
        return {
            'statusCode': 500,
            'body': 'Error removing connection details.',
        }
