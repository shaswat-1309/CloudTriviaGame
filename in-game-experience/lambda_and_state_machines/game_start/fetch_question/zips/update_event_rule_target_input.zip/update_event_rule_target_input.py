import json
import boto3


def lambda_handler(event, context):
    print(event)
    game_id = event['game_id']

    lambda_function_name = 'fetch_question'
    lambda_client = boto3.client('lambda')
    lambda_function_arn = lambda_client.get_function(FunctionName=lambda_function_name)['Configuration']['FunctionArn']

    print(lambda_function_arn)

    rule_name = f'Game-{game_id}-Rule'

    lambda_input_event = json.dumps(event)

    print(lambda_input_event)

    events_client = boto3.client('events')

    put_targets_response = events_client.put_targets(
        Rule=rule_name,
        Targets=[
            {
                'Id': '1',
                'Arn': lambda_function_arn,
                'Input': lambda_input_event
            }
        ]
    )

    print("put_targets_response", put_targets_response)

    return event
