import boto3
import json
import os

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('GameParticipants')  # Replace with your table name
apigatewaymanagementapi = boto3.client('apigatewaymanagementapi', endpoint_url=os.environ['ENDPOINT_URL'])


def lambda_handler(event, context):
    game_id = event['game_id']
    next_question_number = event['question_number']

    try:
        # Fetch all connections from the GameParticipants table
        game_participants_response = get_game_participants(game_id)

        print('game_participants_response', game_participants_response)

        question_details = fetch_question(game_id, next_question_number)

        print('question_details', question_details)

        question_details_str = json.dumps(question_details)

        # Loop through each connection and send the message
        for item in game_participants_response['Items']:
            print(item)
            connection_id = item['connection_id']
            send_message_to_connection(connection_id, question_details_str)

        event['question_number'] += 1

        if event["question_number"] > event["no_of_questions"]:
            event['is_last_question'] = True

        print("updated event", event)

        return event

    except Exception as e:
        print('Error broadcasting message:', e)
        return event


def send_message_to_connection(connection_id, message):
    try:
        apigatewaymanagementapi.post_to_connection(ConnectionId=connection_id, Data=message)
        print("message sent")
    except Exception as e:
        print('Error sending message to connection:', e)


def get_game_participants(game_id):
    # Query the GameParticipants table to get participants by filtering on gameId
    response = table.query(
        KeyConditionExpression='game_id = :game_id',
        ExpressionAttributeValues={':game_id': game_id}
    )
    print(response)
    return response


def fetch_question(game_id, next_question_number):
    dynamodb_client = boto3.client('dynamodb', region_name=os.environ['REGION'])

    # Define the table name
    table_name = 'GameQuestions'

    try:
        # Fetch the question from the DynamoDB table
        response = dynamodb_client.get_item(
            TableName=table_name,
            Key={
                'game_id': {'S': game_id},
                'question_number': {'N': str(next_question_number)}
            }
        )

        # Extract the question details from the response
        question = response.get('Item', {})
        question_details = {
            'question': question.get('question', {}).get('S', ''),
            'options': [option.get('S', '') for option in question.get('options', {}).get('L', [])],
            'correct_option': int(question.get('correct_option', {}).get('N', '0')),
            'hint': question.get('hint', {}).get('S', ''),
            'explanation': question.get('explanation', {}).get('S', ''),
            'question_number': int(question.get('question_number', {}).get('N', ''))
        }

        # Return the question details as a JSON response
        return question_details

    except Exception as e:
        return {
            'error': "question could not be fetched"
        }

