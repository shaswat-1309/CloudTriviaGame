import json
import boto3


def lambda_handler(event, context):
    print(event)

    stepfunctions = boto3.client('stepfunctions')
    response = stepfunctions.start_execution(
        stateMachineArn='arn:aws:states:us-east-1:182296130665:stateMachine:SetupGame',
        # TODO replace with environment variable
        input=json.dumps(event)
    )

    print(response)
