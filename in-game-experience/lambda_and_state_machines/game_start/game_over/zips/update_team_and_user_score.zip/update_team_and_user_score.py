import boto3


def lambda_handler(event, context):
    game_id = event['game_id']
    team_scores = event['team_scores']

    dynamodb = boto3.client('dynamodb')

    # Extract the team names and scores from the response and store in the Teams table
    for team_score in team_scores:
        print(team_score)
        # Update the team table by adding the new score to existing team's score
        dynamodb.update_item(
            TableName='Teams',
            Key={
                'TeamName': {'S': team_score['team']}
            },
            UpdateExpression='ADD Score :score',
            ExpressionAttributeValues={
                ':score': {'N': str(team_score['score'])}
            }
        )

    return event

