import boto3
import json
import os


apigatewaymanagementapi = boto3.client('apigatewaymanagementapi', endpoint_url=os.environ['ENDPOINT_URL'])


def lambda_handler(event, context):
    print("orig event", event)

    question_number = event["question_number"] - 1

    print(f"fetching ans for {question_number} event")

    game_id = event['game_id']

    game_participant_connections = get_game_participants(game_id)
    print('game_participant_connections', game_participant_connections)

    team_scores = event['team_scores']
    team_scores_str = json.dumps(team_scores)

    # Loop through each connection and send the message
    for connection_id in game_participant_connections:
        print("participant connection_id", connection_id)
        send_message_to_connection(connection_id, team_scores_str)

    return event


def send_message_to_connection(connection_id, message):
    try:
        apigatewaymanagementapi.post_to_connection(ConnectionId=connection_id, Data=message)
        print("message sent")
    except Exception as e:
        print('Error sending message to connection:', e)


def get_game_participants(game_id):
    # Query the GameParticipants table to get participants by filtering on gameId

    dynamodb_client = boto3.resource('dynamodb', region_name=os.environ['REGION'])

    game_participants_table = dynamodb_client.Table('GameParticipants')  # Replace with your table name

    # Query the gameparticipants table to get all participants' connection IDs for the game_id
    response = game_participants_table.query(
        KeyConditionExpression='game_id = :game_id',
        ExpressionAttributeValues={':game_id': game_id}
    )

    # Extract the connection IDs from the response
    connection_ids = [item['connection_id'] for item in response['Items']]

    print(connection_ids)
    return connection_ids
