import json

def lambda_handler(event, context):
    # TODO this has to be replaced with Vidhi's leaderboard update lambda
    print('This is leaderboard update lambda!')
    return event
