import json
import requests
import os


def lambda_handler(event, context):
    print(event)

    game_insights_url = os.environ['GAME_INSIGHTS_URL']

    try:
        game_insights_response = requests.post(game_insights_url, json=event)

        if game_insights_response.status_code == 200:
            response = game_insights_response.json()
            print(response)
        else:
            print(f"API call failed with status code: {game_insights_response.status_code}")

    except Exception as e:
        print(f"Error occurred: {str(e)}")

    return event
