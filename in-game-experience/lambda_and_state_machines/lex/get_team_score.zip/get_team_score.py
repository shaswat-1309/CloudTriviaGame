import json
import boto3


def lambda_handler(event, context):
    print(event)

    request_json = json.loads(event['body'])

    team_name = request_json['team_name']
    team_score_details = fetch_score(team_name)
    print(team_score_details)

    return {
        'statusCode': 200,
        "body": json.dumps(team_score_details)
    }


def fetch_score(team_name):
    dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('Teams')

    response = table.get_item(Key={
        "teamName": team_name
    })

    print(response)

    score_details = {}
    if 'Item' in response:
        item = response['Item']
        score_details = {
            "TeamName": item['teamName'],
            "Score": str(item["teamScore"])
        }
    else:
        score_details = {
            "error": "Team does not exist!"
        }
    return score_details
